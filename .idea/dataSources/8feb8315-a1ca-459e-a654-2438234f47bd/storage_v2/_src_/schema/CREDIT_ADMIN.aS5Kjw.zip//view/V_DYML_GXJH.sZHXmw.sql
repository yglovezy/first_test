create view V_DYML_GXJH as
select
        t.mlid,
        t.mlbbid,
        t.mlbmbmid,
        t.mlzwmc,
        t.mlywmc,
        t.mlflid,
        (select m.MLFLMC from T_MLGL_MLFL m where t.MLFLID=m.MLFLID) mlflmc,
        t.mlbm,
        t.mlgxfs,
        t.mlgxtj,
        t.mlgxlx,
        t.sfshkf,
        t.kftj,
        t.sjgjzq,
        t.xxxzlx,
        t.xxztlx,
        t.sjgxzq,
        (select paramname from T_DIR_PARAMETER dir where t.sjgxzq = dir.paramid) sjgxzqmc,
        t.mlms,
        t.mlzt,
        to_char(t.createtime,'yyyy-mm-dd') createdate,
        to_char(t.fbsj,'yyyy-mm-dd') fbsjdate,
        t.mlzygs,
        t.xxfgfw,
        t.glfljlm,
        t.sfjb,
        t.createuserid
        from T_MLGL_DQFWML t
/

