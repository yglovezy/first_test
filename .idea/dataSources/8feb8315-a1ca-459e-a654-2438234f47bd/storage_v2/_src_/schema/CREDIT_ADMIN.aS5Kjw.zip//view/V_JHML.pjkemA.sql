create view V_JHML as
select t.mlid,t.mlzwmc,t.ssbmid
from t_mlgl_dqjhml t
/

