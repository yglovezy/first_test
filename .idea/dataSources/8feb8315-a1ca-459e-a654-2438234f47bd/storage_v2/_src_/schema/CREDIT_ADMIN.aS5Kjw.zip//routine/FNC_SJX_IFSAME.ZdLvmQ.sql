create FUNCTION "FNC_SJX_IFSAME" (v_type IN VARCHAR2,v_mlzj IN VARCHAR2,v_sjxid IN VARCHAR2)
RETURN number AS
a0 varchar2(4000);
a1 varchar2(4000);
a2 varchar2(4000);
a3 varchar2(4000);
a4 varchar2(4000);
a5 varchar2(4000);
a6 varchar2(4000);
a7 varchar2(4000);
a8 varchar2(4000);
b0 varchar2(4000);
b1 varchar2(4000);
b2 varchar2(4000);
b3 varchar2(4000);
b4 varchar2(4000);
b5 varchar2(4000);
b6 varchar2(4000);
b7 varchar2(4000);
b8 varchar2(4000);
sfxt varchar2(4000);
BEGIN
select b.SJXMC,b.GXSX,b.JLDW,b.SYZDMC,b.SJXMS,b.SFQY,b.SJCD,b.SJJD,b.TXSM into b0,b1,b2,b3,b4,b5,b6,b7,b8 from t_mlgl_sjxglb b where b.sjxid=v_sjxid;
if v_type = 'jc' then
  select j.sjxmc,j.GXSX,j.JLDW,j.SYZDMC,j.SJXMS,j.SFQY,j.SJCD,j.SJJD,j.TXSM  into a0,a1,a2,a3,a4,a5,a6,a7,a8 from t_mlgl_jcmllssjx j where j.mlzj=v_mlzj and j.sjxid = v_sjxid;
elsif  v_type = 'kz' then
 select j.sjxmc,j.GXSX,j.JLDW,j.SYZDMC,j.SJXMS,j.SFQY,j.SJCD,j.SJJD,j.TXSM  into a0,a1,a2,a3,a4,a5,a6,a7,a8 from t_mlgl_kzmllssjx j where j.mlzj=v_mlzj and j.sjxid = v_sjxid;
elsif  v_type = 'fw' then
  select j.sjxmc,j.GXSX,j.JLDW,j.SYZDMC,j.SJXMS,j.SFQY,j.SJCD,j.SJJD,j.TXSM  into a0,a1,a2,a3,a4,a5,a6,a7,a8 from t_mlgl_fwmllssjx j where j.mlzj=v_mlzj and j.sjxid = v_sjxid;
elsif  v_type = 'jh' then
  select j.sjxmc,j.GXSX,j.JLDW,j.SYZDMC,j.SJXMS,j.SFQY,j.SJCD,j.SJJD,j.TXSM  into a0,a1,a2,a3,a4,a5,a6,a7,a8 from t_mlgl_jhmllssjx j where j.mlzj=v_mlzj and j.sjxid = v_sjxid;
elsif  v_type = 'dy' then
  select j.sjxmc,j.GXSX,j.JLDW,j.SYZDMC,j.SJXMS,j.SFQY,j.SJCD,j.SJJD,j.TXSM  into a0,a1,a2,a3,a4,a5,a6,a7,a8 from t_mlgl_dymlsjx j where j.mlid=v_mlzj and j.sjxid = v_sjxid;
elsif  v_type = 'cj' then
  select j.sjxmc,j.GXSX,j.JLDW,j.SJXZD,j.SJXMS,j.SFQY,j.SJCD,j.SJJD,j.TXSM  into a0,a1,a2,a3,a4,a5,a6,a7,a8 from t_mlgl_cjmllssjx j where j.lsmlzj=v_mlzj and j.sjxid = v_sjxid;
end if;
select count(*) into sfxt from(
select b0,b1,b2,b3,b4,b5,b6,b7,b8 from dual minus
select a0,a1,a2,a3,a4,a5,a6,a7,a8 from dual);
return sfxt;
--if a1 = b1 and a2=b2 and a3=b3 and a4=b4 and a5=b5 and a6=b6 and a7=b7 then
--    return 1;
--  else
--    return 0;
--  end if;
EXCEPTION
WHEN OTHERS THEN
return -1;
END;
/

