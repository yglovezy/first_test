create view V_SJX_ML as
  (
select
  x.SJXID,
  'fw' AS MLLX,
  t.mlzj,
  t.MLID,
  t.MLZWMC,
  t.MLYWMC,
  t.MLBM,
  case when t.MLZT='0' then '未审核'
      when t.MLZT='1' then '审核中'
        when t.MLZT='2' then '已审核'
           when t.MLZT='3' then '已发布'
       end MLZT,
  f.MLFLMC,
  f.MLFLID,
  d.MLBQMC,
  d.MLBQID,
  FNC_QUERY_PARAMNAME ( t.MLGXLX ) AS MLGXLX,
  to_char( t.CREATETIME, 'yyyy-mm-dd' ) AS CREATEDATE,
  (SELECT FNC_SJX_IFSAME('fw',t.mlzj,x.sjxid) AS sfxt FROM DUAL) sfxt
  FROM
    T_MLGL_FWMLLSSJX x
    right JOIN
    (select * from(
    select row_number() over(partition by l.mlid order by l.createtime desc) rn,l.* from
    T_MLGL_FWMLLS l)where rn =1) t ON x.MLZJ = t.MLZJ
    LEFT JOIN T_MLGL_MLFL f ON t.MLFLID = f.MLFLID
    LEFT JOIN (
    SELECT
      c.MLZJ,
      listagg ( l.MLBQMC, ',' ) within GROUP ( ORDER BY l.MLBQMC ) AS MLBQMC ,
      listagg ( l.MLBQID, ',' ) within GROUP ( ORDER BY l.MLBQID ) AS MLBQID
    FROM
      T_MLGL_FWMLLS c
      LEFT JOIN T_MLGL_FWMLLSBQ l ON c.MLZJ = l.MLZJ
    GROUP BY
      c.MLZJ
    ) d ON t.MLZJ = d.MLZJ
  )UNION ALL
  (
 select
    x.SJXID,
    'jc' AS MLLX,
    t.mlzj,
    t.MLID,
    t.MLZWMC,
    t.MLYWMC,
    t.MLBM,
    case when t.MLZT='0' then '未审核'
      when t.MLZT='1' then '审核中'
        when t.MLZT='2' then '已审核'
           when t.MLZT='3' then '已发布'
       end MLZT,
    f.MLFLMC,
    f.MLFLID,
    d.MLBQMC,
    d.MLBQID,
    FNC_QUERY_PARAMNAME ( t.MLGXLX ) AS MLGXLX,
    to_char( t.CREATETIME, 'yyyy-mm-dd' ) AS CREATEDATE,
  (SELECT FNC_SJX_IFSAME('jc',t.mlzj,x.sjxid) AS sfxt FROM DUAL) sfxt
  FROM
    T_MLGL_JCMLLSSJX x
    right JOIN
    (select * from(
    select row_number() over(partition by l.mlid order by l.createtime desc) rn,l.* from
    T_MLGL_JCMLLS l)where rn =1) t ON x.MLZJ = t.MLZJ
    LEFT JOIN T_MLGL_MLFL f ON t.MLFLID = f.MLFLID
    LEFT JOIN (
    SELECT
      c.MLZJ,
      listagg ( l.MLBQMC, ',' ) within GROUP ( ORDER BY l.MLBQMC ) AS MLBQMC  ,
      listagg ( l.MLBQID, ',' ) within GROUP ( ORDER BY l.MLBQID ) AS MLBQID
    FROM
      T_MLGL_JCMLLS c
      LEFT JOIN T_MLGL_JCMLLSBQ l ON c.MLZJ = l.MLZJ
    GROUP BY
      c.MLZJ
    ) d ON t.MLZJ = d.MLZJ
  ) UNION ALL
  (
  select
    x.SJXID,
    'kz' AS MLLX,
    t.mlzj,
    t.MLID,
    t.MLZWMC,
    t.MLYWMC,
    t.MLBM,
    case when t.MLZT='0' then '未审核'
      when t.MLZT='1' then '审核中'
        when t.MLZT='2' then '已审核'
           when t.MLZT='3' then '已发布'
       end MLZT,
    f.MLFLMC,
    f.MLFLID,
    d.MLBQMC,
    d.MLBQID,
    FNC_QUERY_PARAMNAME ( t.MLGXLX ) AS MLGXLX,
    to_char( t.CREATETIME, 'yyyy-mm-dd' ) AS CREATEDATE,
  (SELECT FNC_SJX_IFSAME('kz',t.mlzj,x.sjxid) AS sfxt FROM DUAL) sfxt
  FROM
    T_MLGL_KZMLLSSJX x
    right JOIN
    (select * from(
    select row_number() over(partition by l.mlid order by l.createtime desc) rn,l.* from
    T_MLGL_KZMLLS l) where rn =1) t ON x.MLZJ = t.MLZJ
    LEFT JOIN T_MLGL_MLFL f ON t.MLFLID = f.MLFLID
    LEFT JOIN (
    SELECT
      c.MLZJ,
      listagg ( l.MLBQMC, ',' ) within GROUP ( ORDER BY l.MLBQMC ) AS MLBQMC  ,
      listagg ( l.MLBQID, ',' ) within GROUP ( ORDER BY l.MLBQID ) AS MLBQID
    FROM
      T_MLGL_KZMLLS c
      LEFT JOIN T_MLGL_KZMLLSBQ l ON c.MLZJ = l.MLZJ
    GROUP BY
      c.MLZJ
    ) d ON t.MLZJ = d.MLZJ
  ) UNION ALL
  (
 select
    x.SJXID,
    'jh' AS MLLX,
    t.mlzj,
    t.MLID,
    t.MLZWMC,
    t.MLYWMC,
    t.MLBM,
    case when t.MLZT='0' then '未审核'
      when t.MLZT='1' then '审核中'
        when t.MLZT='2' then '已审核'
           when t.MLZT='3' then '已发布'
       end MLZT,
    f.MLFLMC,
    f.MLFLID,
    d.MLBQMC,
    d.MLBQID,
    FNC_QUERY_PARAMNAME ( t.MLGXLX ) AS MLGXLX,
    to_char( t.CREATETIME, 'yyyy-mm-dd' ) AS CREATEDATE,
  (SELECT FNC_SJX_IFSAME('jh',t.mlzj,x.sjxid) AS sfxt FROM DUAL) sfxt
  FROM
    T_MLGL_JHMLLSSJX x
    right JOIN
    (select * from(
    select row_number() over(partition by l.mlid order by l.createtime desc) rn,l.* from
    T_MLGL_JHMLLS l ) where rn =1) t ON x.MLZJ = t.MLZJ
    LEFT JOIN T_MLGL_MLFL f ON t.MLFLID = f.MLFLID
    LEFT JOIN (
    SELECT
      c.MLZJ,
      listagg ( l.MLBQMC, ',' ) within GROUP ( ORDER BY l.MLBQMC ) AS MLBQMC  ,
      listagg ( l.MLBQID, ',' ) within GROUP ( ORDER BY l.MLBQID ) AS MLBQID
    FROM
      T_MLGL_JHMLLS c
      LEFT JOIN T_MLGL_JHMLLSBQ l ON c.MLZJ = l.MLZJ
    GROUP BY
    c.MLZJ
  ) d ON t.MLZJ = d.MLZJ
   )UNION ALL
  (
  SELECT
    x.SJXID,
    'dy' AS MLLX,
    t.mlid mlzj,
    t.MLID,
    t.MLZWMC,
    t.MLYWMC,
    t.MLBM,
    case when t.MLZT='0' then '未审核'
      when t.MLZT='1' then '审核中'
        when t.MLZT='2' then '已审核'
           when t.MLZT='3' then '已发布'
       end MLZT,
    f.MLFLMC,
    f.MLFLID,
    d.MLBQMC,
    d.MLBQID,
    FNC_QUERY_PARAMNAME ( t.MLGXLX ) AS MLGXLX,
    to_char( t.CREATETIME, 'yyyy-mm-dd' ) AS CREATEDATE,
  (SELECT FNC_SJX_IFSAME('dy',t.mlid,x.sjxid) AS sfxt FROM DUAL) sfxt
  FROM
    T_MLGL_DYMLSJX x
    LEFT JOIN T_MLGL_DYML t ON x.MLID = t.MLID
    LEFT JOIN T_MLGL_MLFL f ON t.MLFLID = f.MLFLID
    LEFT JOIN (
    SELECT
      c.MLID,
      listagg ( l.MLBQMC, ',' ) within GROUP ( ORDER BY l.MLBQMC ) AS MLBQMC  ,
      listagg ( l.MLBQID, ',' ) within GROUP ( ORDER BY l.MLBQID ) AS MLBQID
    FROM
      T_MLGL_DYML c
      LEFT JOIN T_MLGL_MLMLBQ m ON c.MLID = m.MLID
      LEFT JOIN T_MLGL_MLBQ l ON m.MLBQID = l.MLBQID
    GROUP BY
    c.MLID
  ) d ON t.MLID = d.MLID
  )
  UNION ALL
  (
 select
    x.SJXID,
    'cj' AS MLLX,
    t.LSMLZJ mlzj,
    t.MLID,
    t.MLZWMC||'_'||(select d.deptname from credit_admin.t_sys_department d where t.ssbmid = d.deptid) mlzwmc,
    t.MLYWMC,
    t.MLBM,
    case when t.MLZT='0' then '未发布'
      when t.MLZT='1' then '已发布'
       end MLZT,
    f.MLFLMC,
    f.MLFLID,
    d.MLBQMC,
    d.MLBQID,
    FNC_QUERY_PARAMNAME ( t.MLGXLX ) AS MLGXLX,
    to_char( t.CREATETIME, 'yyyy-mm-dd' ) AS CREATEDATE,
  (SELECT FNC_SJX_IFSAME('cj',t.lsmlzj,x.sjxid) AS sfxt FROM DUAL) sfxt
  FROM
    T_MLGL_CJMLLSSJX x
    right JOIN
    (select * from(
select row_number() over(partition by l.ssbmid,l.mlid order by l.createtime desc) rn,l.* from
    T_MLGL_CJMLLS l) where rn=1) t ON x.LSMLZJ = t.LSMLZJ
    LEFT JOIN T_MLGL_MLFL f ON t.MLFLID = f.MLFLID
    LEFT JOIN (
    SELECT
      c.LSMLZJ,
      listagg ( l.MLBQMC, ',' ) within GROUP ( ORDER BY l.MLBQMC ) AS MLBQMC  ,
      listagg ( l.MLBQID, ',' ) within GROUP ( ORDER BY l.MLBQID ) AS MLBQID
    FROM
      T_MLGL_CJMLLS c
      LEFT JOIN T_MLGL_CJMLLSBQ l ON c.LSMLZJ = l.LSMLZJ
    GROUP BY
    c.LSMLZJ
  ) d ON t.LSMLZJ = d.LSMLZJ
  )
/

