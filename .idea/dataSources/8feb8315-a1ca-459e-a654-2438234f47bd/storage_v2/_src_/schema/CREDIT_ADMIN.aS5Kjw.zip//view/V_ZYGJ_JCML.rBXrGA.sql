create view V_ZYGJ_JCML as
select ml."MLID",ml."MLBBID",ml."MLBBH",ml."MLFLID",ml."MLBMBMID",ml."MLZWMC",ml."MLYWMC",ml."MLBM",ml."MLGXFS",ml."MLGXTJ",ml."MLGXLX",ml."SFSHKF",ml."KFTJ",ml."SJGJZQ",ml."XXXZLX",ml."XXZTLX",ml."SJGXZQ",ml."MLMS",ml."MLZT",ml."CREATETIME",ml."FBSJ",ml."MLZYGS",ml."XXFGFW",ml."GLFLJLM",ml."SFJB",ml."CREATEUSERID",ml."MLFLMC",ml."SJGXZQNAME",ml."SJGJZQID",ml."XXFGFWNAME",ml."MLZYGSNAME",ml."XXZTLXNAME",ml."XXXZLXNAME",ml."MLGXLXNAME",ml."MLGXFSNAME",ml."MLGXTJNAME",ml."MLBMBS",ml."CREATEDATE",ml."FBSJDATE",ml."MLBQMC",ml."SFRJCK", z.zygjpzid
  from credit_resource.t_sjzygl_zygjml z
  left join (select *
               from (select t.mlid,
                            t.mlbbid,
                            t.mlbbh,
                            t.mlflid,
                            t.mlbmbmid,
                            t.mlzwmc,
                            t.mlywmc,
                            t.mlbm,
                            t.mlgxfs,
                            t.mlgxtj,
                            t.mlgxlx,
                            t.sfshkf,
                            t.kftj,
                            t.sjgjzq,
                            t.xxxzlx,
                            t.xxztlx,
                            t.sjgxzq,
                            t.mlms,
                            t.mlzt,
                            t.createtime,
                            t.fbsj,
                            t.mlzygs,
                            t.xxfgfw,
                            t.glfljlm,
                            t.sfjb,
                            t.createuserid,
                            m.mlflmc,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.SJGXZQ) SJGXZQNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.SJGJZQ) SJGJZQid,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.XXFGFW) XXFGFWNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLZYGS) MLZYGSNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.XXZTLX) XXZTLXNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.XXXZLX) XXXZLXNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLGXLX) MLGXLXNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLGXFS) MLGXFSNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLGXTJ) MLGXTJNAME,
                            substr(t.mlbm, 4) mlbmbs,
                            to_char(t.CREATETIME, 'yyyy-mm-dd') AS CREATEDATE,
                            to_char(t.FBSJ, 'yyyy-mm-dd') AS FBSJDATE,
                            (select to_char(wmsys.wm_concat(q.mlbqmc))
                               from t_mlgl_mlbq q, t_mlgl_mlmlbq mm
                              where q.mlbqid = mm.mlbqid
                                and mm.mlid = t.mlid) MLBQMC,
                            SFRJCK
                       from T_MLGL_DQKZML t
                       left join T_MLGL_MLFL m
                         on t.mlflid = m.mlflid)
              WHERE SFRJCK = 1
             union
             select *
               from (select t.mlid,
                            t.mlbbid,
                            t.mlbbh,
                            t.mlflid,
                            t.mlbmbmid,
                            t.mlzwmc,
                            t.mlywmc,
                            t.mlbm,
                            t.mlgxfs,
                            t.mlgxtj,
                            t.mlgxlx,
                            t.sfshkf,
                            t.kftj,
                            t.sjgjzq,
                            t.xxxzlx,
                            t.xxztlx,
                            t.sjgxzq,
                            t.mlms,
                            t.mlzt,
                            t.createtime,
                            t.fbsj,
                            t.mlzygs,
                            t.xxfgfw,
                            t.glfljlm,
                            t.sfjb,
                            t.createuserid,
                            m.mlflmc,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.SJGXZQ) SJGXZQNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.SJGJZQ) SJGJZQNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.XXFGFW) XXFGFWNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLZYGS) MLZYGSNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.XXZTLX) XXZTLXNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.XXXZLX) XXXZLXNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLGXLX) MLGXLXNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLGXFS) MLGXFSNAME,
                            (select r.paramname
                               from T_DIR_PARAMETER r
                              where r.paramid = t.MLGXTJ) MLGXTJNAME,
                            substr(t.mlbm, 4) mlbmbs,
                            to_char(t.CREATETIME, 'yyyy-mm-dd') AS CREATEDATE,
                            to_char(t.FBSJ, 'yyyy-mm-dd') AS FBSJDATE,
                            (select to_char(wmsys.wm_concat(q.mlbqmc))
                               from t_mlgl_mlbq q, t_mlgl_mlmlbq mm
                              where q.mlbqid = mm.mlbqid
                                and mm.mlid = t.mlid) MLBQMC,
                            null
                       from T_MLGL_DQJCML t
                       left join T_MLGL_MLFL m
                         on t.mlflid = m.mlflid)
              where 1 = 1) ml
    on z.mlid = ml.mlid
/

